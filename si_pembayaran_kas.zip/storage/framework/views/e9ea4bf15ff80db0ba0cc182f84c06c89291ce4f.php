<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role_id == 1): ?>
        <div class="row justify-content-end">
            <div class="col-lg-3 col-xs-12 text-end">
                <button type="button" class="btn btn-block bg-light mb-3" data-bs-toggle="modal" data-bs-target="#modal-default">Tambah Data</button>
            </div>
        </div>
    <?php else: ?>
        <div class="row justify-content-end">
            <form method="POST" action="<?php echo e(route('pembayaran.filter')); ?>">
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-3"></div>
                    <div class="col-2">
                        <span class="text-xs font-weight-bold" style="color: aliceblue">From</span>
                        <input class="form-control" type="date" name="start" value="<?php echo e($startDate->format('Y-m-d')); ?>" id="example-month-input">
                    </div>
                    <div class="col-2">
                        <span class="text-xs font-weight-bold" style="color: aliceblue">To</span>
                        <input class="form-control" type="date" name="end" value="<?php echo e($endDate->format('Y-m-d')); ?>" id="example-month-input">
                    </div>
                    <div class="col-4">
                        <span class="text-xs font-weight-bold" style="color: rgba(240, 248, 255, 0)"><br> </span>
                        <button type="submit" class="btn btn-block bg-light mb-3" data-bs-toggle="modal" data-bs-target="#modal-default">Filter Data</button>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <?php if(auth()->user()->role_id == 2): ?>
                    <h6>Laporan Pembayaran</h6>
                    <?php else: ?>
                    <h6>Data Konfirmasi Pembayaran</h6>
                    <?php endif; ?>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive">
                        <table id="tableTagihan" class="table align-items-center justify-content-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Tanggal Pembayaran</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        No Tagihan</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">
                                        User</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Jumlah Bayar</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">
                                        Status</th>
                                    <?php if(auth()->user()->role_id == 1): ?>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-2">
                                                <div class="my-auto">
                                                    <h6 class="mb-0 text-sm"><?php echo e($key+1); ?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0"><?php echo e($row->tgl_bayar); ?></p>
                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold"><?php echo e($row->id_tagihan); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold"><?php echo e($row->tagihan->user->name); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold"><?php echo e($row->total_bayar); ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <?php if($row->status_bayar == 0): ?>
                                                <span class="me-2 text-xs font-weight-bold badge bg-gradient-info">Menunggu Konfirmasi</span>
                                            <?php elseif($row->status_bayar == 1): ?>
                                            <span class="me-2 text-xs font-weight-bold badge bg-gradient-success">Valid</span>
                                            <?php else: ?>
                                                <span class="me-2 text-xs font-weight-bold badge bg-gradient-danger">Invalid</span>
                                            <?php endif; ?>
                                        </td>

                                        <?php if(auth()->user()->role_id == 1): ?>
                                        <td class="align-middle">
                                            <div class="dropdown">
                                                <button class="btn btn-link text-secondary mb-0" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fa fa-ellipsis-v text-xs" aria-hidden="true"></i>
                                                </button>
                                                <?php if(auth()->user()->role_id == 1 && $row->status_bayar == 0): ?>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modal-edit-<?php echo e($row->id); ?>">Edit</a></li>
                                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modal-konfirmasi-<?php echo e($row->id); ?>">Konfirmasi</a></li>
                                                <li>
                                                    <form action="<?php echo e(route('pembayaran.destroy', $row->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="dropdown-item" onclick="return confirm('Hapus data ini?')" type="submit" >Delete</button>
                                                    </form>
                                                </li>
                                            </ul>
                                            <?php endif; ?>
                                            </div>
                                        </td>
                                        <?php endif; ?>
                                    </tr>

                                    <div class="modal fade" id="modal-edit-<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal-edit" aria-hidden="true">
                                        <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="modal-title-default">Edit Pembayaran</h6>
                                                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                                                </button>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('pembayaran.update',[$row->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                                <div class="modal-body">
                                                    <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="example-text-input" class="form-control-label">Tanggal Bayar</label>
                                                            <input type="date" class="form-control" name="tgl_bayar" value="<?php echo e($row->tgl_bayar); ?>" id="exampleFormControlInput1">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="example-text-input" class="form-control-label">No Tagihan</label>
                                                            <select class="form-control" id="select1" name="id_tagihan">
                                                                <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($data->id_tagihan); ?>" <?php echo e($data->id_tagihan == $row->id_tagihan ? 'selected' : ''); ?>>Tagihan No <?php echo e($data->id_tagihan); ?> - <?php echo e($data->user->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="example-text-input" class="form-control-label">Jumlah</label>
                                                                <input type="text" class="form-control" name="total_bayar" value="<?php echo e($row->total_bayar); ?>" id="exampleFormControlInput1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" name="action" value="edit" class="btn bg-gradient-primary">Save changes</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="modal-konfirmasi-<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal-konfirmasi" aria-hidden="true">
                                        <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="modal-title-default">Konfirmasi Pembayaran</h6>
                                                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                                                </button>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('pembayaran.update',[$row->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                                <div class="modal-body">
                                                    <div class="row">
                                                    <div class="col-md-1"></div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <img width="250" src="<?php echo e(asset($row->bukti_bayar)); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1"></div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="example-text-input" class="form-control-label">No Tagihan</label>
                                                            <input type="text" readonly class="form-control" value="No Tagihan <?php echo e($row->id_tagihan); ?> - <?php echo e($row->tagihan->user->name); ?>" id="exampleFormControlInput1">
                                                            <input type="hidden" class="form-control" value="<?php echo e($row->id_tagihan); ?>" id="exampleFormControlInput1">
                                                            <label for="example-text-input" class="form-control-label">Jumlah</label>
                                                            <input type="number" value="<?php echo e($row->total_bayar); ?>" class="form-control" id="exampleFormControlInput1">
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" name="action" value="konfirmasi"  class="btn bg-gradient-primary">Konfirmasi Pembayaran</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php if(auth()->user()->role_id == 2): ?>
    <div class="row">
        <div class="col-xl-3 col-sm-6 mb-4">
        </div>
        <div class="col-xl-6 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Pembayaran</p>
                        <div class="col-9">
                            <div class="numbers">
                                <h5 class="font-weight-bolder">
                                    Rp. <?php echo e($total); ?>

                                </h5>
                                
                            </div>
                        </div>
                        <div class="col-3 text-end">
                            <div
                                class="icon icon-shape bg-gradient-secondary shadow-secondary text-center rounded-circle">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-4">
        </div>
    </div>
    <?php endif; ?>

    <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="modal-title-default">Tambah Pembayaran</h6>
                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <form method="POST" action="<?php echo e(route('pembayaran.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-text-input" class="form-control-label">Tanggal Bayar</label>
                            <input type="date" name="tgl_bayar" class="form-control" id="exampleFormControlInput1">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-text-input" class="form-control-label">No Tagihan</label>
                            <select class="form-control" id="select2" name="id_tagihan">
                                <option hidden selected>-- Select Tagihan --</option>
                                <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tagihan->id_tagihan); ?>">Tagihan No <?php echo e($tagihan->id_tagihan); ?> - <?php echo e($tagihan->user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="example-text-input" class="form-control-label">Jumlah</label>
                                <input type="number" class="form-control" id="exampleFormControlInput1" name="total_bayar">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn bg-gradient-primary">Save changes</button>
                </div>
            </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script>
        $(".nav-link").removeClass("active")
        $("#nav-link-pembayaran").addClass("active")

        $(document).ready(function() {
            $('#tableTagihan').DataTable();

            styleDatatable("tableTagihan")
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\si_pembayaran_kas2\resources\views/pembayaran.blade.php ENDPATH**/ ?>