<?php $__env->startSection('content'); ?>
    <div class="row justify-content-end">
        <div class="col-lg-3 col-xs-12 text-end">
            <button type="button" class="btn btn-block bg-success mb-3" data-bs-toggle="modal" data-bs-target="#modal-qr">QR Pembayaran</button>
            <?php if(auth()->user()->role_id == 1): ?>
                <button type="button" class="btn btn-block bg-light mb-3" data-bs-toggle="modal" data-bs-target="#modal-default">Tambah Data</button>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Data Tagihan</h6>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive">
                        <table id="tableTagihan" class="table align-items-center justify-content-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Tanggal</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Keterangan</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        User</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Jumlah</th>
                                    <th
                                        class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">
                                        Status</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-2">
                                                <div class="my-auto">
                                                    <h6 class="mb-0 text-sm"><?php echo e($key+1); ?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0"><?php echo e($row->tgl_tagihan); ?></p>
                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold"><?php echo e($row->keterangan); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold"><?php echo e($row->user->name); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold"><?php echo e($row->jumlah); ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <?php if($row->status_tagihan == 0): ?>
                                                <span class="me-2 text-xs font-weight-bold badge bg-gradient-danger">Belum Bayar</span>
                                            <?php elseif($row->status_tagihan == 1): ?>
                                                <span class="me-2 text-xs font-weight-bold badge bg-gradient-info">Menunggu Konfirmasi</span>
                                            <?php else: ?>
                                                <span class="me-2 text-xs font-weight-bold badge bg-gradient-success">Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="align-middle">
                                            <div class="dropdown">
                                                <button class="btn btn-link text-secondary mb-0" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fa fa-ellipsis-v text-xs" aria-hidden="true"></i>
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <?php if(auth()->user()->role_id == 2 && $row->status_bayar == 0): ?>
                                                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modal-bayar-<?php echo e($row->id); ?>">Upload Bukti</a></li>
                                                    <?php endif; ?>
                                                    <?php if(auth()->user()->role_id == 1): ?>
                                                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modal-edit-<?php echo e($row->id); ?>">Edit</a></li>
                                                        <?php if($row->status_tagihan == 0): ?>
                                                            <li>
                                                                <form action="<?php echo e(route('tagihan.destroy', $row->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button class="dropdown-item" onclick="return confirm('Hapus data ini?')" type="submit" >Delete</button>
                                                                </form>
                                                            </li>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="modal-edit-<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal-edit" aria-hidden="true">
                                        <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="modal-title-default">Edit Tagihan</h6>
                                                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                                                </button>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('tagihan.update',[$row->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                                <div class="modal-body">
                                                        <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="example-text-input" class="form-control-label">Tanggal Tagihan</label>
                                                                <input type="date" class="form-control" required name="tgl_tagihan" value="<?php echo e($row->tgl_tagihan); ?>"  id="exampleFormControlInput1">
                                                                <input type="hidden" class="form-control" required name="id_tagihan" value="<?php echo e($row->id); ?>" id="exampleFormControlInput1">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="example-text-input" class="form-control-label">User</label>
                                                                <select class="form-control" required id="select2" name="id_user">
                                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $row->id_user ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label for="example-text-input" class="form-control-label">Jumlah</label>
                                                                    <input type="text" class="form-control" required name="jumlah"  value="<?php echo e($row->jumlah); ?>"  id="exampleFormControlInput1">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="form-group">
                                                                    <label for="example-text-input" class="form-control-label">Keterangan</label>
                                                                    <input type="text" class="form-control" required name="keterangan" value="<?php echo e($row->keterangan); ?>"  id="exampleFormControlInput1">
                                                                    <input type="hidden" class="form-control" required name="status_tagihan" value="0" id="exampleFormControlInput1">
                                                                </div>
                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn bg-gradient-primary">Save changes</button>
                                            </form>
                                            </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="modal-bayar-<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal-bayar" aria-hidden="true">
                                        <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="modal-title-default">Upload Bukti</h6>
                                                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                                                </button>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('pembayaran.store')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="example-text-input" class="form-control-label">Tanggal Bayar</label>
                                                                <input type="date" class="form-control" required name="tgl_bayar" id="exampleFormControlInput1">
                                                                <input type="hidden" class="form-control" required name="id_tagihan" value="<?php echo e($row->id_tagihan); ?>" id="exampleFormControlInput1">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label for="example-text-input" class="form-control-label">Jenis Pembayaran</label>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="metode_bayar" value="2" id="customRadio2">
                                                                <label class="custom-control-label" for="customRadio2">Dana</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="example-text-input" class="form-control-label">Bukti Bayar</label>
                                                                <input type="file" class="form-control" required  name="bukti_bayar" id="exampleFormControlInput1">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="example-text-input" class="form-control-label">Jumlah</label>
                                                                <input type="number" class="form-control" name="total_bayar" <?php echo e($row->jumlah); ?>  required id="exampleFormControlInput1">
                                                                <input type="hidden" class="form-control" name="status_bayar" value="0" required id="exampleFormControlInput1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn bg-gradient-primary">Bayar</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php if(auth()->user()->role_id == 2): ?>
        <div class="row">
            <div class="col-xl-4 col-sm-6 mb-4">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="row">
                            <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Tagihan Belum Bayar</p>
                            <div class="col-9">
                                <div class="numbers">
                                    <h5 class="font-weight-bolder">
                                        Rp. <?php echo e($totalBlmBayar); ?> / <?php echo e($jmlhBlmBayar); ?> Tagihan
                                    </h5>
                                    
                                </div>
                            </div>
                            <div class="col-3 text-end">
                                <div
                                    class="icon icon-shape bg-gradient-secondary shadow-secondary text-center rounded-circle">
                                    <i class="fas fa-user"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-sm-6 mb-4">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="row">
                            <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Tagihan Belum Terkonfirmasi</p>
                            <div class="col-9">
                                <div class="numbers">
                                    <h5 class="font-weight-bolder">
                                        Rp. <?php echo e($totalBlmKonfrim); ?> / <?php echo e($jmlhBlmKonfrim); ?> Tagihan
                                    </h5>
                                    
                                </div>
                            </div>
                            <div class="col-3 text-end">
                                <div
                                    class="icon icon-shape bg-gradient-secondary shadow-secondary text-center rounded-circle">
                                    <i class="fas fa-money-check"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-sm-6 mb-4">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="row">
                            <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Tagihan Terkonfirmasi</p>
                            <div class="col-9">
                                <div class="numbers">
                                    <h5 class="font-weight-bolder">
                                        Rp. <?php echo e($totalKonfrim); ?> / <?php echo e($jmlhKonfrim); ?> Tagihan
                                    </h5>
                                    
                                </div>
                            </div>
                            <div class="col-3 text-end">
                                <div
                                    class="icon icon-shape bg-gradient-secondary shadow-secondary text-center rounded-circle">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="modal-title-default">Tambah Tagihan</h6>
                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <form method="POST" action="<?php echo e(route('tagihan.store')); ?>">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                        <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="example-text-input" class="form-control-label">Tanggal Tagihan</label>
                                <input type="date" class="form-control" required name="tgl_tagihan" id="exampleFormControlInput1">
                                <input type="hidden" class="form-control" required name="id_tagihan" value="<?php echo e($id); ?>" id="exampleFormControlInput1">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="example-text-input" class="form-control-label">User</label>
                                <select class="form-control" required id="select2" name="id_user">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Jumlah</label>
                                    <input type="text" class="form-control" required name="jumlah" id="exampleFormControlInput1">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Keterangan</label>
                                    <input type="text" class="form-control" required name="keterangan" id="exampleFormControlInput1">
                                    <input type="hidden" class="form-control" required name="status_tagihan" value="0" id="exampleFormControlInput1">
                                    <input type="hidden" class="form-control" required name="notifikasi_status" value="0" id="exampleFormControlInput1">
                                </div>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn bg-gradient-primary">Save changes</button>
                </div>
                </div>
            </form>
        </div>
    </div>



    <div class="modal fade" id="modal-qr" tabindex="-1" role="dialog" aria-labelledby="modal-bayar" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="modal-title-default">Pembayaran</h6>
                <button type="button" class="btn-close bg-dark" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="customRadio2">
                                <label class="custom-control-label" for="customRadio2">Dana</label>
                            </div>
                            <img width="340" src="<?php echo e(asset('/assets/img/dana.png')); ?>">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link  ml-auto" data-bs-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

    <script>
        $(".nav-link").removeClass("active")
        $("#nav-link-tagihan").addClass("active")

        $(document).ready(function() {
            $('#tableTagihan').DataTable();

            styleDatatable("tableTagihan")
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\si_pembayaran_kas2\resources\views/tagihan.blade.php ENDPATH**/ ?>